#include "begin_position_condition.h"

bool begin_position_condition::update(position * pos)
{
//   jesli zachodzi warunek, sprawdz czy moze byc wykonana akcja
//   return true jesli moze byc wykonana akcja
   if(pos->x==10)
   {
     return check();
   }
  return false;
}