#include "switch_task.h"
switch_task::switch_task(const std::vector<void (*)()> & reftask, std::vector<begin_position_condition *> & refbegin_conditions, const std::vector<terminate_position_condition*> &refterminate_conditions, position* pos)
  {
	std::cout<<"Konstruktor"<<std::endl;
 	tasks=reftask;
	std::cout<<pos<<"\t"<<pst<<std::endl;
 	pst=pos;
	std::cout<<pos<<"\t"<<pst<<std::endl;
        begin_conditions=refbegin_conditions;
        terminate_conditions=refterminate_conditions;    
	actual=0;
	toexec=tasks.size();
  }
  void switch_task::execute()
  { 
      if(actual>=toexec)
	return;
      std::cout<<"Switch_Task"<<std::endl;
      if(!action)
      {
	  std::cout<<"Begin Update!!!\n";
 	  action=begin_conditions[actual]->update(pst);
      }
      if(action)
      {
	  std::cout<<"Funkcja pracuje\n";
 	  tasks[actual]();
      }	
      if(!terminate)
      {
	  std::cout<<"Terminate Update!\n";
	  terminate=terminate_conditions[actual]->update(pst);
      }
      if(terminate)
      {
	  std::cout<<"Terminate action\n";
 	  ++actual;
 	  action=false;
      }
  }// execute()
