#ifndef POSITION_H_
#define POSITION_H_
#include <iostream>

class position
{
public:
	int x;
	int y;
	int z;
	void add2x(){std::cout<<"Zwiekszam x"<<std::endl; x++;}
	void sub2x(){x--;}
	void add2y(){y++;}
	void sub2y(){y--;} 
	void add2z(){std::cout<<"Zwiekszam z"<<std::endl;z++;}
	void sub2z(){z--;}
	position(){x=y=z=0;}
  
};


#endif
