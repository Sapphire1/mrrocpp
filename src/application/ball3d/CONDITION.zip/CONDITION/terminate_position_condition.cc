#include "terminate_position_condition.h" 

bool terminate_position_condition::update(position * pos)
{
  if(pos->z==15)
  {
    return check();
  }
  return false;
}
