#ifndef SWITCH_TASK_H_
#define SWITCH_TASK_H_
#include <vector>
#include <iostream>
#include "begin_position_condition.h"
#include "terminate_position_condition.h"
#include "position.h"

class switch_task
{
public:
  std::vector<int (*)(int,int)> functions;
  std::vector<void (*)()> tasks;
  std::vector<begin_position_condition*> begin_conditions;
  std::vector<terminate_position_condition*> terminate_conditions;
  bool terminate;
  bool action;
  int actual, toexec;
  position* pst;
  switch_task(const std::vector<void (*)()> &, std::vector<begin_position_condition *> &, const std::vector<terminate_position_condition*> &, position *);
  void execute();
  
};// class switch_task

#endif