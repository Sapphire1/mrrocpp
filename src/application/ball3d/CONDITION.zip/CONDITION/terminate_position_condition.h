#ifndef TERMINATE_POSITION_CONDITION_H_
#define TERMINATE_POSITION_CONDITION_H_
#include "terminate_condition.h"
#include "position.h"

class terminate_position_condition : public terminate_condition
{

public:
	terminate_position_condition(){};
	~terminate_position_condition(){};
	bool update(position *);

};

#endif 
