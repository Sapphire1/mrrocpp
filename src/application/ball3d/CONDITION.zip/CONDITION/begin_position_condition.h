#ifndef BEGIN_POSITION_CONDITION_H_
#define BEGIN_POSITION_CONDITION_H_
#include "begin_condition.h"
#include "position.h"

class begin_position_condition : public begin_condition
{	
public:
	begin_position_condition(){};
	~begin_position_condition(){};
	bool update(position *);
};

#endif


