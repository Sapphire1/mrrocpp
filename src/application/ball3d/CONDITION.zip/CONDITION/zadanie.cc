#include <iostream>
#include <vector>
#include "begin_position_condition.h"
#include "terminate_position_condition.h"
#include "switch_task.h"
#include "position.h"

using std::vector;

position* pos;
void add2x() { pos->add2x(); }
void add2z() { pos->add2z(); }


int main()
{
	std::vector<void (*)()> fun;
	std::vector<int (*)(int,int)> f;
	std::vector<begin_position_condition*> bpc_vcr;
	std::vector<terminate_position_condition*> tpc_vcr;
	begin_position_condition* bpc = new begin_position_condition();
	terminate_position_condition* tpc= new  terminate_position_condition();
  	pos = new position();
	fun.push_back(add2z);
	bpc_vcr.push_back(bpc);
	tpc_vcr.push_back(tpc);

     	switch_task * sch_tsk = new switch_task(fun,bpc_vcr,tpc_vcr, pos);
   	
	
	for(int i=0;i<50;i++)
 	{
	  std::cout<<"pos->x= "<<pos->x<< "\t";
	  std::cout<<"pos->z= "<<pos->z<< std::endl;
	  pos->x++;
 	    sch_tsk->execute();
 	}
	delete pos;
 	delete bpc;
	delete tpc;
 	delete sch_tsk;
	
	
 return 0;
}